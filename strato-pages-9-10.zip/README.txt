STRATO REPORT PAGES 9-10

To connect to your existing CashSouk prospectus:

1. Add this after your existing stylesheet:
   <link rel="stylesheet" href="strato-pages.css">

2. Paste the contents of strato-pages.html immediately after your last existing prospectus <section class="page">.

The new sections use:
   <section class="page strato-page">

So they keep the same page flow while all additional CSS is prefixed with strato- to avoid breaking your existing prospectus styles.

preview.html is a standalone browser preview.
